from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from app.models.base import Base

class ChatRoom(Base):
    __tablename__ = "chat_rooms"
    
    room_id = Column(Integer, primary_key=True, autoincrement=True)
    room_name = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.now)

    # Relationship with messages
    messages = relationship("Message", back_populates="chat_room", cascade="all, delete-orphan")
    
    def __repr__(self) -> str:
        return f"<ChatRoom(room_id={self.room_id!r}, room_name={self.room_name!r}, created_at={self.created_at!r})>"
