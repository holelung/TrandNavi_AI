from flask import Blueprint, jsonify, request, Response
from app.services.naver_shopping_service import get_naver_shopping_data, format_product_info, get_price_comparison
from app.services.trend_service import get_related_topics
from app.llm_config import llm, prompt, trend_template, extract_keyword
from app.redis_handler import RedisChatMemory
from flask_jwt_extended import jwt_required, get_jwt_identity
import json

chat_bp = Blueprint('chat', __name__)

@chat_bp.route('/chat/<int:room_id>', methods=['POST'])
@jwt_required()
def chat(room_id):
    """
    채팅 요청을 처리하고 LLM 기반 응답을 스트리밍 방식으로 반환.
    Redis를 통해 채팅 기록을 관리하며, 채팅방별로 기록을 구분.
    """
    user_message = request.json.get('message', '').strip()
    if not user_message:
        return jsonify({"error": "Message cannot be empty."}), 400

    user_id = get_jwt_identity()
    if not user_id:
        return jsonify({"error": "Unauthorized"}), 401

    session_id = f"room_{room_id}_user_{user_id}"
    redis_memory = RedisChatMemory(session_id)

    def generate_response():
        try:
            # 트렌드 분석 요청 처리
            if "트렌드" in user_message or "유행" in user_message:
                yield f"data: {json.dumps({'response': '트렌드 데이터를 가져오는 중입니다...'})}\n\n"
                keyword = extract_keyword(user_message)
                if not keyword:
                    yield f"data: {json.dumps({'response': '키워드를 추출할 수 없습니다.'})}\n\n"
                    return

                trend_data = get_related_topics(keyword)
                if trend_data:
                    rising_topics = "\n".join([f"{i+1}. {topic['title']} ({topic['value']})" for i, topic in enumerate(trend_data['rising'])])
                    top_topics = "\n".join([f"{i+1}. {topic['title']} ({topic['value']})" for i, topic in enumerate(trend_data['top'])])

                    messages = trend_template.format(
                        keyword=keyword,
                        rising_topics=rising_topics,
                        top_topics=top_topics,
                        history="\n".join(redis_memory.get_recent_history(limit=5)),
                        human_input=user_message
                    )
                    response = ""
                    for chunk in llm.stream(messages):
                        if chunk.content:
                            response += chunk.content
                            yield f"data: {json.dumps({'response': response})}\n\n"
                    redis_memory.save_context(user_message, response)
                else:
                    error_message = "트렌드 정보를 가져오는 데 실패했습니다."
                    redis_memory.save_context(user_message, error_message)
                    yield f"data: {json.dumps({'response': error_message})}\n\n"
                return

            # 가격 비교 요청 처리
            if "가격 비교" in user_message:
                yield f"data: {json.dumps({'response': '가격 정보를 가져오는 중입니다...'})}\n\n"
                min_price, max_price = get_price_comparison(user_message)
                price_comparison_response = f"최저가: {min_price}원, 최고가: {max_price}원"
                redis_memory.save_context(user_message, price_comparison_response)
                yield f"data: {json.dumps({'response': price_comparison_response})}\n\n"
                return

            # 네이버 쇼핑 API 요청 및 LLM 처리
            items = get_naver_shopping_data(user_message)
            product_info = format_product_info(items) if items else "상품 정보를 찾을 수 없습니다."
            recent_history = redis_memory.get_recent_history(limit=5)

            messages = prompt.format_messages(
                product_info=product_info,
                history="\n".join(recent_history),
                human_input=user_message
            )

            full_response = ""
            for chunk in llm.stream(messages):
                if chunk.content:
                    full_response += chunk.content
                    yield f"data: {json.dumps({'response': full_response})}\n\n"

            redis_memory.save_context(user_message, full_response)
        except Exception as e:
            error_message = f"오류가 발생했습니다: {str(e)}"
            yield f"data: {json.dumps({'response': error_message})}\n\n"

    return Response(generate_response(), content_type='text/event-stream')
